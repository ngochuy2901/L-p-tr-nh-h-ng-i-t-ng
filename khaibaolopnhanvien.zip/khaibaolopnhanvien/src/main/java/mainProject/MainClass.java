/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainProject;

/**
 *
 * @author huy
 */
public class MainClass {

    public static void main(String[] args) {
        employee a = new employee();
        a.input();
        a.convertBirthDay();
        a.convertContractDay();
        a.output();
    }
}
