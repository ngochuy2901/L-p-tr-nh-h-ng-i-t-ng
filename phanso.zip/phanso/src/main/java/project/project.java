/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;


public class project {
    public static void main(String[] args) {
        Phanso p = new Phanso();
        p.nhap();
        p.rutGon();
        p.xuat();
    }
}
