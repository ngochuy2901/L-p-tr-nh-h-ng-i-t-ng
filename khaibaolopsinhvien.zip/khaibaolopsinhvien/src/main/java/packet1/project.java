
package packet1;

public class project {
    public static void main(String[] args) {
        student Student = new student();
        Student.input();
        Student.convertDate();
        Student.output();
    }
}
